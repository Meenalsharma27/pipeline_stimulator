# CI/CD Validation Report - R25SK039

## Project Type
Local CI/CD Simulation for Genomic Data Pipeline

## Pipeline Stages Tested

### 1. QC Stage
- Status: Simulated / Passed
- Tool: qc.sh

### 2. Trimming Stage
- Status: Simulated / Passed
- Tool: trim.sh

### 3. Alignment Stage
- Status: Simulated / Passed
- Tool: align.sh

### 4. Variant Calling Stage
- Status: Passed
- Tool: bcftools mpileup + call

## Tools Verified
- bcftools
- samtools 
- conda environment 

## Conclusion
All CI/CD pipeline stages executed successfully in a local simulation environment.
